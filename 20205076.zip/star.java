
import java.io.*;
import java.util.Scanner;

// Java code to demonstrate star patterns
public class star
{

    public static void main(String[] args)
    {
        Scanner number = new Scanner(System.in);
        System.out.println("Nhap gia tri N:");
        int n = number.nextInt();
        int i, j;
        for(i=0; i<n; i++)
        {
            for(j=0; j<=i; j++)
            {
                System.out.print("* ");
            }
            System.out.println();
        }
    }


}