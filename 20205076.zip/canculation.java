import java.util.Scanner;
public class canculation {
    public static void main(String[] args) {
        Scanner x = new Scanner(System.in);
        System.out.println("Nhap gia tri 1");
        double num1 = x.nextDouble();
        System.out.println("Nhap gi tri 2");
        double num2 = x.nextDouble();
            System.out.printf("Tong = %3f \n", num1 + num2);
            System.out.printf("Hieu = %3f \n", num1 - num2);
            System.out.printf("Tich = %3f \n", num1 * num2);
        if (num2 == 0) {
            System.out.println("So chia khong the nhan gia tri 0\n Xin moi nhap lai");
        }else {
            System.out.printf("Thuong = %f \n", num1/num2);
        }

}}
