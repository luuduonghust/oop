public class arraylab {
    public static void main(String[] args) {
        int [] a = {1,2,3,40,10};
        int sum =0;
        int temp;
        for (int i=0; i<a.length; i++){
            sum = sum + a[i];
        }
        int average = sum/a.length;
        System.out.println("Gia tri trung binh cong la:" + average);
        for (int i = 0; i < a.length; i++)
        {
            for (int j = i + 1; j < a.length; j++) {
                if (a[i] > a[j])
                {
                    temp = a[i];
                    a[i] = a[j];
                    a[j] = temp;
                }
            }
        }
        System.out.print("Kết quả sau khi được sắp xếp: ");
        for (int i = 0; i < a.length - 1; i++)
        {
            System.out.print(a[i] + ", ");
        }
        System.out.print(a[a.length - 1]);
    }
}
