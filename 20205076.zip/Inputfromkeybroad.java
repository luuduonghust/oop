import java.util.Scanner;
public class Inputfromkeybroad {
    public static void main(String[] args) {
        Scanner Keybroad = new Scanner(System.in);
        System.out.println("What your name?");
        String strName = Keybroad.nextLine();
        System.out.println("How old are you?");
        int iAge = Keybroad.nextInt();
        System.out.println("How tall are you(m)?");
        double dHeight = Keybroad.nextDouble();

        System.out.println("Mrs/Ms." + strName + "," + iAge + " years old."
        + "Your height is " + dHeight + ".");
    }
}
