import java.util.Scanner;
        public class solveone {
            public static void main(String[] args) {
                double a,b,c,d,e,f;
                Scanner input = new Scanner(System.in);
                System.out.println("Nhap gia tri a1");
                    a = input.nextDouble();
                System.out.println("Nhap gia tri b1");
                    b = input.nextDouble();
                System.out.println("Nhap gia tri c");
                    c = input.nextDouble();
                System.out.println("Nhap gia tri a2");
                    d = input.nextDouble();
                System.out.println("Nhap gia tri b2");
                    e = input.nextDouble();
                System.out.println("Nhap gia tri d");
                    f = input.nextDouble();
                double det = 1/ ((a) * (d) - (b) * (c));
                double x = ((d) * (e) - (b) * (f)) / det;
                double y = ((a) * (f) - (c) * (e)) / det;
                System.out.print("x=" + x + " y=" + y);
            }
}