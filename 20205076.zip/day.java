import java.util.Scanner;
public class day {
    public static void main(String[] args) {
        Scanner date = new Scanner(System.in);
        System.out.println("Nhap ngay:");
        int days =date.nextInt();
        if ( days > 32) {
            System.out.println("Moi nhap lai ngay");
            days = date.nextInt();
            }
        System.out.println("Nhap thang");
        int  months = date.nextInt();
        if (months > 13) {
            System.out.println("Nhap lai thang");
            months = date.nextInt();
            }
        System.out.println("Nhap nam");
        double years = date.nextDouble();
        if (years>9999) {
            System.out.println("Nhap lai nam");
            years = date.nextDouble();
            }
    System.out.println("Ngay " + days + "," + "Thang " + months +","+ "Nam "+ years + ".");
    }
}
