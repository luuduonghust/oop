import java.util.ArrayList;
import java.util.List;
public class Cart {
    public static final int MAX_NUMBERS_ORDERED = 20;
    private List<DigitalVideoDisc> itemOrder = new ArrayList<DigitalVideoDisc>();
    private int qtyOrdered = 0;
    public void addDigitalVideoDisc(DigitalVideoDisc disc) {
        if (qtyOrdered < MAX_NUMBERS_ORDERED) {
            itemOrder.add(disc);
            qtyOrdered += 1;
                System.out.println("Da them vao gio hang");
        } else {
                System.out.println("Gio hang day");
        }
    }
    public void removeDigitalVideoDisc(DigitalVideoDisc disc) {
        if (itemOrder.isEmpty()) {
            System.out.println("Gio hang trong");
            return;
        }

        if (itemOrder.remove(disc)) {
            qtyOrdered -= 1;
            System.out.println("Dax xoa dvd");
        } else {
            System.out.println("Dvd khong ton tai");
        }
    }
    public float totalCost() {
        if (qtyOrdered == 0) {
            return 0;
        }
        float totalCoat = 0;
        for (DigitalVideoDisc digitalVideoDisc : itemOrder) {
            totalCoat += digitalVideoDisc.getCoat();
        }
        return totalCoat;
    }
}
